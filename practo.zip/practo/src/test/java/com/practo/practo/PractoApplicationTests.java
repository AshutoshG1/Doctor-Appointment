package com.practo.practo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PractoApplicationTests {

	@Test
	void contextLoads() {
	}

}
